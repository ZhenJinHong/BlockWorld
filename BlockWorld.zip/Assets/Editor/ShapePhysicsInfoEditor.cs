﻿using CatDOTS.VoxelWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;

namespace CatFramework.EditorTool
{
    //[CustomEditor(typeof(ShapePhysicsInfo))]
    //[CustomPropertyDrawer(typeof(ShapePhysicsInfo))]
    //public class ShapePhysicsInfoEditor : PropertyDrawer
    //{
    //    public override VisualElement CreatePropertyGUI(SerializedProperty property)
    //    {
    //        return base.CreatePropertyGUI(property);
    //    }
    //    public override VisualElement CreateInspectorGUI()
    //    {
    //        VisualElement container = new VisualElement();
    //        container.Add(new Button());
    //        InspectorElement.FillDefaultInspector(container, serializedObject, this);

    //        return container;
    //    }
    //}
}
