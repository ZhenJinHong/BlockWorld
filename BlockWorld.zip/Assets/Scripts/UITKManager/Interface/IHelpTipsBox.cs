﻿using System;
using System.Collections.Generic;

namespace CatFramework.UiTK
{
    public interface IHelpTipsBox
    {
        string Title { get; set; }
    }
}
