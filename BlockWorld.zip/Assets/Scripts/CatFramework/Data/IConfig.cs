﻿namespace CatFramework
{
    /// <summary>
    /// 全局配置，关于建筑，人物等之类的血量配置等
    /// </summary>
    public interface IConfig
    {
        string Name { get; }
    }
}
