﻿using System;

namespace CatFramework
{
    public interface IDataCollection : IDisposable
    {
    }
    ///// <summary>
    ///// 
    ///// </summary>
    ///// <typeparam name="T">持有者</typeparam>
    //public interface IDataCollection<T> : IDataCollection
    //    where T : class
    //{

    //}
}
