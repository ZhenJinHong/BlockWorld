﻿namespace CatFramework
{
    public interface IDynamicViewModule
    {
        bool Update();
    }
}