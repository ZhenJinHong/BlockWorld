﻿namespace CatFramework
{
    // 用户/玩家负责输入,游戏内对象响应变化
    public interface IUser : IModule
    {

    }
}
