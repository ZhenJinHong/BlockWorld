﻿namespace CatFramework
{
    public interface ICollectionView : IEnableDirtyView
    {

    }
}
