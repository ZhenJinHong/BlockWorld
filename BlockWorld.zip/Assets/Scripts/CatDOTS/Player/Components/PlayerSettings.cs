﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Unity.Entities;

//namespace CatDOTS
//{
//    public struct PlayerSettings : IComponentData
//    {
//        public float TopAngle;
//        public float BottomAngle;
//    }
//}
