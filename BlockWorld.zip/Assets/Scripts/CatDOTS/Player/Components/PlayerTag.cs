﻿//using System;
//using System.Collections.Generic;
//using Unity.Entities;
//using Unity.Mathematics;

//namespace CatDOTS
//{
//    public struct PlayerTag : IComponentData
//    {
//    }
//}
