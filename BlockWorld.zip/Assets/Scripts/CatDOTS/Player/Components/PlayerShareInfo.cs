﻿//using Unity.Entities;
//using Unity.Mathematics;

//namespace CatDOTS
//{
//    public struct PlayerShareInfo : IComponentData
//    {
//        public float3 Position;
//    }
//}
