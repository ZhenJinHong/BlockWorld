﻿using System;
using Unity.Entities;

namespace CatDOTS
{
    public struct SingletonSystemEntity : IComponentData
    {
    }
}
