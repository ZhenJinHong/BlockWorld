﻿using System;
namespace CatDOTS
{
    public enum Direction : byte
    {
        North北,
        South南,
        West西,
        East东,
        NorthEast东北,
        NorthWest西北,
        SouthEast东南,
        SouthWest西南,
        Random,
    }
}
