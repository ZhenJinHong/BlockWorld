﻿namespace CatDOTS
{
    public enum AnimationClipID : byte
    {
        Idle,
        Watch,
        Walk,
        Run,
        Attack,
    }
}