﻿namespace CatFramework.Magics
{
    public class MagicBox
    {

    }
}