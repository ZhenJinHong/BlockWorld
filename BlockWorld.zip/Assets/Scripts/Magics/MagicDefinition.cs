﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CatFramework.Magics
{
    //public interface IMagicDefinition
    //{
    //    string Name { get; }
    //    Texture2D Icon { get; }

    //    IMagic GetMagic();
    //    IMagic GetMagic(string data);
    //}
    //[CreateAssetMenu(fileName = "New MagicDefinition", menuName = "ECSVoxelWorld/MagicDefinition")]
    //public class MagicDefinition : ScriptableObject, IMagicDefinition
    //{
    //    [SerializeField] Texture2D icon;
    //    public Texture2D Icon => icon;
    //    public string Name => name;
    //    public virtual IMagic GetMagic()
    //    {
    //        return new Magic();
    //    }
    //    public virtual IMagic GetMagic(string data)
    //    {
    //        return new Magic();
    //    }
    //}
}
