﻿namespace CatFramework.Magics
{
    public interface IMagicWandHolder
    {

    }
}
