﻿//using CatFramework.EventsMiao;
//using System;

//namespace CatFramework.GameManager
//{
//    public interface IGameStatusEvents<GameData> : IUniqueEvents
//    {
//        event Action<GameData> OnEnter;
//        event Action<GameData> OnPause;
//        event Action<GameData> OnContinue;
//        event Action<GameData> OnExit;
//        void Continue(GameData gameStatusData);
//        void Enter(GameData gameStatusData);
//        void Exit(GameData gameStatusData);
//        void Pause(GameData gameStatusData);
//    }
//}
