﻿//using CatFramework.UiMiao;
//using System;
//using System.Collections;
//using UnityEngine.UI;

//namespace VoxelWorld.UGUICTR
//{
//    public class QualitySettingsView : BaseSettingDataView<QualitySettingsData>
//    {
//        //protected override void SetOtherUI(CommonUIPrefabs commonUIPrefabs)
//        //{
//        //    base.SetOtherUI(commonUIPrefabs);
//        //    DropdownMiao qulityLevel = commonUIPrefabs.InstantiateDropdown(content);
//        //    qulityLevel.Label = "质量";
//        //    qulityLevel.AddOptions(setting.GetAllQualityLevel());
//        //    qulityLevel.SetValueWithoutNotify(setting.QualityLevel);
//        //    qulityLevel.OnSubmit += SetQulityLevel;
//        //}
//        //void SetQulityLevel(TInputField<int> field)
//        //{
//        //    setting.QualityLevel = field.GetValue();
//        //}
//    }
//}