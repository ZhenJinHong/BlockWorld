﻿//using CatFramework.DataMiao;
//using CatFramework.Tools;
//using CatFramework.UiMiao;
//using System.Collections;
//using UnityEngine;

//namespace VoxelWorld.UGUICTR
//{
//    public class PlayerSettingView : BaseSettingDataView<PlayerSettingData>
//    {
//    }
//}