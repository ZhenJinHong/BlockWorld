﻿//using System.Collections;
//using UnityEngine;

//namespace VoxelWorld.UGUICTR
//{
//    internal class DebugSettingView : BaseSettingDataView<DebugSetting>
//    {
//    }
//}