﻿//using System.Collections;
//using UnityEngine;

//namespace VoxelWorld.UGUICTR
//{
//    public class OutGameView : MonoBehaviour
//    {

//    }
//}