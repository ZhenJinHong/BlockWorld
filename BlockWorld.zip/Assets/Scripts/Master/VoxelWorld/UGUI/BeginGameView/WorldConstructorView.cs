﻿//using CatDOTS.VoxelWorld;
//using CatFramework.EventsMiao;
//using CatFramework.Tools;
//using CatFramework.UiMiao;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//namespace VoxelWorld.UGUICTR
//{
//    public class WorldConstructorView : MonoBehaviour
//    {
//        //[SerializeField] StringFlipPageListView stringFlipPageListView;
//        //GameCassette.IDataCollection dataCollection;
//        //GameCassette.IDataCollection DataCollection
//        //{
//        //    get { dataCollection ??= EventManagerMiao.GetPulisher<GameCassette.Controller>().Data; return dataCollection; }
//        //}
//        //List<string> constructors;
//        //void Start()
//        //{
//        //    constructors = new List<string>();
//        //    ListUtility.ListConverter<IWorldGeneratorConstructor, string>(DataCollection.WorldGeneratorDefinitions, constructors, (c) => c.GetType().Name);
//        //    stringFlipPageListView.Items = constructors;
//        //    stringFlipPageListView.OnSelectedItem += Selected;
//        //}
//        //private void OnDestroy()
//        //{
//        //    if (stringFlipPageListView != null)
//        //    {
//        //        stringFlipPageListView.OnSelectedItem -= Selected;
//        //    }
//        //}
//        //void Selected(int index)
//        //{
//        //    IWorldGeneratorConstructor worldGeneratorConstructor = DataCollection.WorldGeneratorDefinitions[index];
//        //}
//    }
//}