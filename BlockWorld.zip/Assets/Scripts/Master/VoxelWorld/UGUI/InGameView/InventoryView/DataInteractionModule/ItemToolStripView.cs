﻿using CatFramework;
using CatFramework.UiMiao;
using System.Collections;
using UnityEngine;

namespace VoxelWorld.UGUICTR
{
    //public abstract class ItemGestureProcessor : MonoBehaviour
    //{
    //    //[SerializeField] UlatticeDataInteraction ulatticeDataInteraction;
    //    //protected UlatticeDataInteraction UlatticeDataInteraction => ulatticeDataInteraction;
    //    public abstract void Processed(LatticeClick latticeClick, IInventory inventory);
    //}
    //public class ItemToolStripContentProvider
    //{

    //}
    //public class ItemToolStripView : MonoBehaviour
    //{
    //    //[SerializeField] UlatticeDataInteraction ulatticeDataInteraction;
    //    private void Awake()
    //    {
    //        ulatticeDataInteraction.OnItemIsClick += UlatticeClick;
    //    }
    //    private void OnDestroy()
    //    {
    //        ulatticeDataInteraction.OnItemIsClick -= UlatticeClick;
    //    }
    //    void UlatticeClick(LatticeClick latticeClick)
    //    {
    //    }
    //}
}