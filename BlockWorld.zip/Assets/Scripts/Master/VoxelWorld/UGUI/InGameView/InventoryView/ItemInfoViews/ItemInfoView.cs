﻿//using CatFramework.UiMiao;
//using System.Collections;
//using UnityEngine;

//namespace VoxelWorld.UGUICTR
//{
//    public abstract class ItemInfoView : MonoBehaviour
//    {
//        protected virtual void Start()
//        {
//            Close();
//        }
//        protected void Open()
//        {
//            gameObject.SetActive(true);
//        }
//        protected void Close()
//        {
//            gameObject.SetActive(false);
//        }
//        public abstract bool ShowInfo(IUlatticeItem ulatticeItem);
//    }
//}