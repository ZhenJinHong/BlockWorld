﻿namespace CatFramework
{
    [System.Serializable]
    public class Non_ScriptCfg
    {
    }
}