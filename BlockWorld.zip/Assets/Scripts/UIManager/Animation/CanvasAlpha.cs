﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using UnityEngine;

//namespace CatFramework.UiMiao
//{
//    public class CanvasAlpha
//    {
//        CanvasGroup canvasGroup;
        
//        public CanvasAlpha(CanvasGroup canvasGroup)
//        {

//        }
//        public void Update()
//        {

//        }
//    }
//}
