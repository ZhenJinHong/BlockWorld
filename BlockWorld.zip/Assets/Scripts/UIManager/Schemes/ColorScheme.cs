﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework.UiMiao
//{
//    [CreateAssetMenu(fileName = "New ColorScheme", menuName = "UGUIStyle/ColorScheme")]
//    public class ColorScheme : ScriptableObject
//    {
//        [SerializeField] Color[] colors;
//    }
//}