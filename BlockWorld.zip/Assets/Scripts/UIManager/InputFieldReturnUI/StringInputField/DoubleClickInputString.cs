﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework
//{
//    public sealed class DoubleClickInputString : DoubleClickInputText<string>
//    {
//        protected override string ProcessText(string text)
//        {
//            if (!string.IsNullOrWhiteSpace(text))
//            {
//                return text;
//            }
//            return value;
//        }
//    }
//}