﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework
//{
//    public sealed class Float3InputField : T3InputField<float>
//    {
//    }
//}