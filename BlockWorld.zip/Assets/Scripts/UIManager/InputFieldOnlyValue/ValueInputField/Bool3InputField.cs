﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework
//{
//    public sealed class Bool3InputField : T3InputField<bool> //设置值或读取存在接口IValue3<bool>与struct的转换
//    {

//    }
//}