﻿using System.Collections;
using System.Collections.Generic;

namespace CatFramework.UiMiao
{
    public class ButtonMiaoFPLVTransfer : PageListViewTransfer<ButtonMiao, IReadOnlyList<IButtonListViewItem>, ButtonMiaoFPLVUMCtr>
    {
    }
}