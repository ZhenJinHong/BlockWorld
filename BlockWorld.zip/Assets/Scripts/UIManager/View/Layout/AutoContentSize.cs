﻿//using System.Collections;
//using UnityEngine;
//using UnityEngine.EventSystems;

//namespace CatFramework.UiMiao
//{
//    public class AutoContentSize : MonoBehaviour
//    {
//        public void R()
//        {
//            //UIBehaviour
//        }
//    }
//}