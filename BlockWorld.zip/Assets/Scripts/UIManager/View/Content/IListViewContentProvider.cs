﻿//using System;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace CatFramework.UiMiao
//{
//    public interface IListViewItemProvider<VisualItem>
//        where VisualItem : class
//    {
//        VisualItem MakeItem();
//        void DestroyItem(VisualItem visualItem);
//        void BindItem(int itemIndex, VisualItem visualItem);
//        void UnBindItem(int itemIndex, VisualItem visualItem);
//    }
//}
