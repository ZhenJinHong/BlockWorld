﻿//using System.Collections;
//using UnityEngine;
//using UnityEngine.UI;

//namespace CatFramework.UiMiao
//{
//    public class LoopScrollListView : MonoBehaviour
//    {

//        void Rebuild()
//        {
//            HorizontalLayoutGroup horizontalLayoutGroup = GetComponent<HorizontalLayoutGroup>();
//            //horizontalLayoutGroup
//            ScrollRect scrollRect = GetComponent<ScrollRect>();
//        }
//    }
//}