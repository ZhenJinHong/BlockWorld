﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//namespace CatFramework.UiMiao
//{
//    public interface ISkillItem : IItemStorage
//    {
//        Sprite Icon { get; }
//        ///// <summary>
//        ///// 提供给Ui做缓冲,以确保是否需要更新Ui,在image里已经判断过了
//        ///// </summary>
//        //float LastCoolingPercent { get; set; }
//        float CoolingPercent { get; }
//    }
    
//}