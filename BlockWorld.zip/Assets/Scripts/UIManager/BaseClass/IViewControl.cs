﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace CatFramework.UiMiao
//{
//    public interface IViewControl
//    {
//        event Action<IViewControl> OnOpen;
//        event Action<IViewControl> OnClose;

//        void Open();
//        void Close();
//    }
//}
