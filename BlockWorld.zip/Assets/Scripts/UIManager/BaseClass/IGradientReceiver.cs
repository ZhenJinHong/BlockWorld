﻿//using UnityEngine;

//namespace CatFramework
//{
//    public interface IGradientReceiver
//    {
//        bool IsDestroy { get; }
//        Gradient Gradient { get; }
//        void GradientChanged();
//        void GradientSubmit();
//    }
//}
