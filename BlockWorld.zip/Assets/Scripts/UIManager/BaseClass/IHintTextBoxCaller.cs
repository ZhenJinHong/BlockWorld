﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using UnityEngine;

//namespace CatFramework
//{
//    public interface IHintTextBoxCaller
//    {
//        bool IsDestory { get; }
//        string HintText { get; }
//        Color HintColor { get; }
//    }
//}
