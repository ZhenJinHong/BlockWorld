﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace CatFramework.PlayerManager
{
    public static class PlayerManagerMiao
    {
        public static Vector3 PlayerPosition;
    }
}
