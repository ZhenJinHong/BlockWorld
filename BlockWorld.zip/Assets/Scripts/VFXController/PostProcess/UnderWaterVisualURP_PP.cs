﻿//using System.Collections;
//using UnityEngine;
//using UnityEngine.Rendering;

//namespace CatFramework.VFX
//{
//    [RequireComponent(typeof(Volume))]
//    public class UnderWaterVisualURP_PP : MonoBehaviour
//    {
//        Volume Volume;
//    }
//}