﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework.InputMiao
//{
//    public class MultiNumInputActionTransfer : MonoBehaviour
//    {
//        [SerializeField] InputActionReferenceWithEvent[] inputNumberActionEvents;
//        void Start()
//        {

//        }
//    }
//}