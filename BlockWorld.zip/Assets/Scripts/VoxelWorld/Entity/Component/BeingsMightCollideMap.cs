﻿//using System;
//using Unity.Collections;
//using Unity.Entities;
//using Unity.Mathematics;

//namespace CatDOTS.VoxelWorld
//{
//    public struct BeingsMightCollideMap : IComponentData
//    {
//        public NativeHashSet<int3> MightPosCheckMap;
//        public NativeParallelMultiHashMap<int3, int3> MightPosMap;
//    }
//}
