﻿//using System;
//using System.Collections.Generic;
//using Unity.Entities;
//using Unity.Transforms;

//namespace CatFrameworkDOTS.VoxelWorld
//{
//    public readonly partial struct EntitySimulationAspect : IAspect
//    {
//        //public readonly RefRW<LocalTransform> transform;
//        //public readonly RefRO<EntityGravityFactor> GravityFactor;
//        public readonly RefRO<EntityVelocity> LinearVelocity;
//        public readonly RefRW<EntityStatus> Status;
//    }
//}
