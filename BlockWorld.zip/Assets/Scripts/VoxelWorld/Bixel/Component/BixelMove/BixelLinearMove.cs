﻿using Unity.Entities;

namespace CatDOTS.VoxelWorld
{
    public struct BixelLinearMove : IComponentData
    {

    }
}
