﻿using Unity.Entities;

namespace CatDOTS.VoxelWorld
{
    public struct VoxelReplace : IComponentData
    {
        public Voxel Hold;
    }
}
