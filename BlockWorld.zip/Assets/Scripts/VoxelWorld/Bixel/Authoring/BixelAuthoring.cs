﻿//using System.Collections;
//using Unity.Entities;
//using UnityEngine;

//namespace CatDOTS.VoxelWorld
//{
//    public class BixelAuthoring : MonoBehaviour
//    {
//        class BixelBaker : Baker<BixelAuthoring>
//        {
//            public override void Bake(BixelAuthoring authoring)
//            {
//                Entity entity = GetEntity(TransformUsageFlags.Dynamic);
//                AddComponent(entity, new Bixel() { });
//            }
//        }
//    }
//}