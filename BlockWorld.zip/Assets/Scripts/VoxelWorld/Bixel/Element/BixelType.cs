﻿namespace CatDOTS.VoxelWorld
{
    public enum BixelType : byte
    {
        None = 0,
        ReplceVoxel = 1,
        SwapVoxel = 2,
    }
}
