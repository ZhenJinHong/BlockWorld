﻿//using Unity.Entities;
//using UnityEngine.Scripting;

//namespace CatDOTS.VoxelWorld
//{
//    [UpdateInGroup(typeof(AlterVoxelSystemGroup))]
//    public partial class BixelAlterVoxelSystemGroup : ComponentSystemGroup
//    {
//        [Preserve]
//        public BixelAlterVoxelSystemGroup() { }
//    }
//}
