﻿/// <summary>
/// 作者：洪镇津（ZhenJin Hong）
/// </summary>
class CatGirlTemplate
{

}
