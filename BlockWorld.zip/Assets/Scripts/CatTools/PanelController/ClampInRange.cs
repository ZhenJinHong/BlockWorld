﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework.Tools
//{
//    public class ClampInRange : MonoBehaviour
//    {
//        [SerializeField] RectTransform target;
//        public void Clamp()
//        {
//            if (target == null) return;
//            DragInRange.ClampInRange(target);
//        }
//    }
//}