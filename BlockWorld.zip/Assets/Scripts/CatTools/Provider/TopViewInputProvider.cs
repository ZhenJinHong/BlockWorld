﻿//using System;
//using UnityEngine;

//namespace CatFramework.Tools
//{
//    public interface ITopViewInputProvider
//    {
//        Vector2 Move { get; }
//        float Lifting { get; }
//        Vector2 MouseDelta { get; }
//    }
//}
