﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework.Tools
//{
//    public class WrapInstantiate : MonoBehaviour
//    {
//        enum WrapMode
//        {
//            Quad,
//        }
//        [SerializeField] GameObject parent;
//        [SerializeField] GameObject prefab;
//        [SerializeField] Vector3 prefabBounds;
//        [SerializeField] int count;
//        void Start()
//        {

//        }
//    }
//}