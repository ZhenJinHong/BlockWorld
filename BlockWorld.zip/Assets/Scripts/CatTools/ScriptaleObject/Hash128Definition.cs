﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework.Tools
//{
//    public class Hash128Definition : ScriptableObject
//    {
//        [SerializeField] Hash128 id;
//    }
//}