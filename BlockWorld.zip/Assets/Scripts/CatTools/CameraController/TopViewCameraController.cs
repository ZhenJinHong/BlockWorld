﻿//using System.Collections;
//using UnityEngine;

//namespace CatFramework.Tools
//{
//    public class TopViewCameraController : MonoBehaviour
//    {
//        public Transform target;
//    }
//}